
/**
 * Write a description of class Triangle here.
 * 
 * @author Dr. Carlos Delgado
 * @version February 2015
 */
// The Triangle class should extend the Shape class.

//Add instance variables unique to the Triangle.

// Implement the Draw Method.
// Inside the Draw method call the 
// Tip you can draw a triangle by calling StdDraw.line 3 times.
