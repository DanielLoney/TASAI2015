
/**
 * Write a description of class Rectangle here.
 * 
 * @author Dr. Carlos Delgado
 * @version February 2015
 */


// The Rectangle class should extend the Shape class.

//Add instance variables unique to the Rectangle.

// Implement the Draw Method.
// Inside the Draw method call the 
// Tip you can draw a rectangle by calling StdDraw.line or StdDraw.polygon
 