
/**
 * Write a description of class Circle here.
 * 
 * @author Dr. Carlos Delgado
 * @version February 2015
 */

// The Circle class should extend the Shape class.

//Add instance variables unique to the Circle.

// Implement the Draw Method.
// 
// Tip you can draw a rectangle by calling StdDraw.circle 
