package classes;

 

/**
 * @author delgadomatac
 *
 */



public class DigitRecognitionRunner {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
         DigitRecognitionFrame frame = new DigitRecognitionFrame ("Digit Recognition by Daniel Loney");
         //frame.setSize(800, 600);
         frame.setVisible(true);
	}

}
